#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "truth_table.h"

void sortedInsert(stack* st, char val) {
    if (isEmpty(st) || val > peek(st)) 
	{
        push(st, val);
        return;
    }
    char temp = pop(st);
    sortedInsert(st, val);
    push(st, temp);
}

void insertionSort(stack* st) {
    if (!isEmpty(st)) 
	{
        char temp = pop(st);
        insertionSort(st);
        sortedInsert(st, temp);
    }
}

stack* getDistinctVar(stack* st)
{
	stack* var = newStack();
	node* itr1 = st->head;
	while(itr1)
	{
		bool found = false;
		if(isalpha(itr1->data))
		{
			if(isEmpty(var))
			{
				push(var,itr1->data);
			}
			else
			{
				node* itr2 = var->head;
				while(itr2)
				{
					if(itr1->data==itr2->data)
					{
						found = true;
						break;
					}
					itr2=itr2->next;
				}
				if(!found)
				{
					push(var,itr1->data);
				}
			}	
		}
		itr1=itr1->next;
	}
	insertionSort(var);
	return var;
}

int* decimal_to_binary(int num, int bits)
{
	int* binary = (int*)calloc(bits,sizeof(int));
	int i = bits-1;
	while(num>0 && i>=0)
	{
		binary[i]=num%2;
		num=num/2;
		i--;
	}
	return binary;
}

int evaluate_psf(char* expr)
{
    stack* st = newStack();
    int len = strlen(expr);
    for (int i = 0; i < len; i++)
    {
        char ch = expr[i];
        if (ch == '1' || ch == '0')
        {
            push(st, ch);
        }
        else if (ch == '\'')
        {
            char op = pop(st);
            int val = op - '0';
            int result = !val;
            push(st, result + '0');
        }
        else if (ch == '+' || ch == '.')
        {
            char op2 = pop(st);
            char op1 = pop(st);
            int val1 = op1 - '0';
            int val2 = op2 - '0';
            int result;
            if (ch == '+')
                result = val1 || val2;
            else
                result = val1 && val2;
            push(st, result + '0');
        }
    }
    int final = pop(st) - '0';
    free_stack(st);
    return final;
}

bnode** getMinterms(stack* st)
{
    reverseStack(st);
	int st_length = 0;
	node* itr = st->head;
	while(itr)
	{
		st_length++;
		itr = itr->next;
	}
	char* psf_expr = (char*)calloc((st_length+1),sizeof(char));
	itr = st->head;
	int k = 0;
	stack* var = getDistinctVar(st);
	reverseStack(var);
	itr = var->head;
	int length=0;
	while(itr)
	{
		length++;
		itr=itr->next;
	}
	int rows = pow(2,length);
	int cols = length+1;
	bnode** minterms = (bnode**)malloc(rows*sizeof(bnode*));
	for(int i = 0; i<rows; i++)
	{
		minterms[i] = (bnode*)malloc(cols*sizeof(bnode));
	}
	for(int i = 0; i < rows ; i++)
	{
		itr = var->head;
		int* binary = decimal_to_binary(i, length);
        int j=0;
		while(itr)
		{
 			minterms[i][j].data = itr->data;
 			minterms[i][j].val = binary[j];
 			itr= itr->next;
 			j++;
        }
	}
	for(int i = 0; i < rows ; i++)
    {
        itr = st->head;
        k = 0;
        while (itr && k < st_length) {
            psf_expr[k] = itr->data;
            itr = itr->next;
            k++;
        }
        psf_expr[st_length] = '\0';
        for(int j = 0 ; j < cols-1 ; j++)
        {
            itr = st->head;
            k = 0;
            while(itr && k < st_length)
            {
                if(itr->data == minterms[i][j].data)
                {
                    psf_expr[k] = (char)(minterms[i][j].val + '0');
                }
                itr = itr->next;
                k++;
            }
        }
        minterms[i][length].val = evaluate_psf(psf_expr);
    }
	free(psf_expr);
	free_stack(var);
	return minterms;
}