#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h> // For pow()

// Include our new modules
#include "boolean_parser.h"
#include "truth_table.h"
// We don't need to include stack.h here because the other headers already do

// The main logic function, now much cleaner
void generate_json_output(char* expr) {
    stack* st = newStack();
    if (!isValidExpression(expr)) {
        printf("{\"error\":\"Invalid Expression\"}");
        free_stack(st);
        return;
    }

    inf_to_posf(expr, st);
    bnode** minterms = getMinterms(st);
    stack* var = getDistinctVar(st);
    reverseStack(var);

    int length = 0;
    for (node* itr = var->head; itr != NULL; itr = itr->next) {
        length++;
    }
    int rows = pow(2, length);
    int cols = length + 1;

    // --- JSON output generation ---
    // (Copy and paste the JSON printing logic from your previous func() here)
    printf("{\"postfix\":\"");
    node* itr2 = st->head;
    while(itr2)
    {
        printf("%c", itr2->data);
        itr2 = itr2->next;
    }
    printf("\","); // End of postfix key-value pair

    // 2. Print table headers
    printf("\"headers\":[");
    node* itr = var->head;
    while(itr)
    {
        printf("\"%c\"", itr->data);
        if (itr->next != NULL) {
            printf(",");
        }
        itr = itr->next;
    }
    printf(",\"Output\"],"); // Add the "Output" header and end the array

    // 3. Print table rows
    printf("\"rows\":[");
    for(int i = 0; i < rows; i++)
    {
        printf("["); // Start of a row array
        for(int j = 0; j < cols; j++)
        {
            printf("%d", minterms[i][j].val);
            if (j < cols - 1) {
                printf(",");
            }
        }
        printf("]"); // End of a row array
        if (i < rows - 1) {
            printf(",");
        }
    }
    printf("]"); // End of the rows array

    printf("}");


    // --- Cleanup ---
    for (int i = 0; i < rows; i++) {
        free(minterms[i]);
    }
    free(minterms);
    free_stack(var);
    free_stack(st);
}

int main() {
    char str[100];

    // Read a single line from standard input (provided by the Node.js server).
    // Do NOT print any prompts.
    if (fgets(str, 100, stdin) != NULL) {
        str[strcspn(str, "\n")] = '\0'; // Remove trailing newline

        char* processed = addImplicitANDs(str);
        generate_json_output(processed);
        free(processed);
    }

    return 0;
}