#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "boolean_parser.h" // Include its own header

bool hasBalancedParentheses(char *expr)
{
	int len = strlen(expr);
	stack *st = newStack();
	for(int i=0; i<len; i++)
	{
		char ch = expr[i];
		if(ch == '(')
		{
			push(st,ch);
		}
		else if (ch == ')'){
            if (isEmpty(st)) {
                free_stack(st);
                return false;
			}
			char topchar = pop(st);
			if(ch == ')' && topchar != '(')
			{
				free_stack(st);
				return false;
			}
		}
	}
	bool balanced = isEmpty(st);
    free_stack(st);
    return balanced;
}

bool hasValidCharacters(char* expr)
{
	int len = strlen(expr);
	for(int i=0; i<len; i++)
	{
		char ch = expr[i];
		if ((!isalpha(ch) && ch != '+' && ch != '.' && ch != '(' && ch != ')' && ch != '\''))
			return false;
	}
	return true;
}

bool hasValidOperatorPlacement(char* expr)
{
	int len = strlen(expr);
	if(!len)
		return true;
	if (expr[0] == '+' || expr[0] == '.' || expr[len-1] == '+' || expr[len-1] == '.' || expr[0] == '\'') 
        return false;
    for (int i = 0; i < len; i++) {
        char current = expr[i];
        char prev = (i > 0) ? expr[i-1] : '\0';
        char next = (i + 1 < len) ? expr[i+1] : '\0';
        if (current == '+' || current == '.') {
            if (prev == '(' || prev == '+' || prev == '.') return false;
            if (next == ')' || next == '+' || next == '.') return false;
        }
        else if (current == '\'') {
            if (!isalpha(prev) && prev != ')') return false;
        }
        else if (current == '(' && next == ')') {
            return false;
        }
    }
    return true;
}

int pre(char ch)
{
	if(ch=='+') return 1;
	if(ch=='.') return 2;
	if(ch=='\'') return 3;
	return 0;
}

// --- Public Function Implementations ---
char* addImplicitANDs(char* expr) {
    int len = strlen(expr);
    char* newExpr = (char*)malloc(2*len + 1);
    int j = 0;
    for(int i = 0; i < len; i++) {
        char ch = expr[i];
        newExpr[j++] = ch;
        if (i < len - 1) {
            char next = expr[i+1];
            bool curr_is_operand = isalpha(ch) || ch == ')'|| ch == '\'';
            bool next_is_operand = isalpha(next) || next == '(';
            if(curr_is_operand && next_is_operand) {
                newExpr[j++] = '.';
            }
        }
    }
    newExpr[j] = '\0';
    return newExpr;
}

bool isValidExpression(char* expr) {
    if (!hasValidCharacters(expr)) return false;
    if (!hasBalancedParentheses(expr)) return false;
    if (!hasValidOperatorPlacement(expr)) return false;
    return true;
}



void inf_to_posf(char* expr, stack* st)
{
	stack* op = newStack();
	for(int i = 0; i < strlen(expr); i++)
	{
		char ch = expr[i];
		if(isalpha(ch))
		{
			push(st,ch);
		}
		else if(ch=='(')
		{
			push(op,ch);
		}
		else if(ch==')')
		{
			while(!isEmpty(op) && peek(op)!='(')
			{
				push(st,pop(op));
			}
			if(!isEmpty(op))
				pop(op);
		}
		else
		{
			while(!isEmpty(op) && pre(ch)<=pre(peek(op)) && peek(op)!= '(')
			{
				push(st,pop(op));
			}
			push(op,ch);
		}
	}
	while(!isEmpty(op))
	{
		push(st, pop(op));
	}
	free_stack(op);
}