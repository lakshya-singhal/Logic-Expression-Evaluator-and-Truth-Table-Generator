#ifndef TRUTH_TABLE_H
#define TRUTH_TABLE_H

#include "stack.h" // Needs the stack definition

// --- Type Definitions ---
typedef struct bool_node {
    char data;
    int val;
} bnode;

// --- Function Prototypes ---
bnode** getMinterms(stack* st);
stack* getDistinctVar(stack* st); // This is a helper but needed by main

#endif // TRUTH_TABLE_H