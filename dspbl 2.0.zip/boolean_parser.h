#ifndef BOOLEAN_PARSER_H
#define BOOLEAN_PARSER_H

#include <stdbool.h>
#include "stack.h" // Needs the stack definition

// --- Function Prototypes ---
char* addImplicitANDs(char* expr);
bool isValidExpression(char* expr);
void inf_to_posf(char* expr, stack* st);

#endif // BOOLEAN_PARSER_H