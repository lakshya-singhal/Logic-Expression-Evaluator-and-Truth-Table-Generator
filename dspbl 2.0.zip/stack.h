#ifndef STACK_H
#define STACK_H

#include <stdbool.h>

// --- Type Definitions ---
typedef struct node {
    char data;
    struct node* next;
} node;

typedef struct stack {
    node* head;
} stack;

// --- Function Prototypes ---
stack* newStack();
bool isEmpty(stack* st);
void push(stack* st, char val);
char pop(stack* st);
char peek(stack* st);
void free_stack(stack* st);
void reverseStack(stack* st);

#endif // STACK_H