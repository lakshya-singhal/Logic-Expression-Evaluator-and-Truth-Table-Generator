import express from "express";
import bodyParser from "body-parser";
import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

// Support for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

app.use(bodyParser.json());

// Allow cross-origin access (so your local HTML page can call the API)
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  next();
});

app.post("/evaluate", (req, res) => {
  const userInput = req.body.input || "";
  const exePath = path.join(__dirname, "bool_eval.exe");

  const child = spawn(exePath);

  let output = "";
  let errorOutput = "";

  child.stdout.on("data", (data) => {
    output += data.toString();
  });

  child.stderr.on("data", (data) => {
    errorOutput += data.toString();
  });

  child.on("close", (code) => {
    if (code !== 0) {
      res.status(500).json({ error: errorOutput || "Execution failed" });
    } else {
      res.json({ output: output.trim() });
    }
  });

  // Send input to stdin (what the C program expects)
  child.stdin.write(userInput + "\n");
  child.stdin.end();
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
