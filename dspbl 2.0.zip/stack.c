#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "stack.h" // Include the header file for this module

// Private helper function, not needed outside this file
static node* newNode(char data) {
    node* temp = (node*)malloc(sizeof(node));
    temp->data = data;
    temp->next = NULL;
    return temp;
}

stack* newStack() {
    stack* temp = (stack*)malloc(sizeof(stack));
    temp->head = NULL;
    return temp;
}

bool isEmpty(stack* st) {
    return (st->head == NULL);
}

void push(stack* st, char val) {
    node* temp = newNode(val);
    temp->next = st->head;
    st->head = temp;
}

char pop(stack* st) {
    if (isEmpty(st)) {
        return '\0'; // Return null char on underflow
    }
    node* temp = st->head;
    char rt = temp->data;
    st->head = st->head->next;
    free(temp);
    return rt;
}

char peek(stack* st) {
    if (isEmpty(st)) {
        return '\0';
    }
    return st->head->data;
}

void free_stack(stack* st) {
    if (st == NULL) {
        return;
    }
    node* current = st->head;
    node* temp;
    while (current != NULL) {
        temp = current->next;
        free(current);
        current = temp;
    }
    free(st);
}

void reverseStack(stack* st) {
    node *prev = NULL, *current = st->head, *next = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    st->head = prev;
}